module Input where

import Graphics.UI.GLFW (Key(..), keyIsPressed)
import Control.Monad (when)

char :: Char -> IO () -> IO ()
char = key . CharKey

key :: Key -> IO () -> IO ()
key k act = do
  p <- keyIsPressed k
  when p act

escape :: IO () -> IO ()
escape = key KeyEsc

backspace :: IO () -> IO ()
backspace = key KeyBackspace
