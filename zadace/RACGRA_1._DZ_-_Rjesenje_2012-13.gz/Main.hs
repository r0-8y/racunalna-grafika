module Main where

import qualified Model  (load, fromSpline, orient, draw)
import qualified Spline (load, inter, tangent)
import qualified Input  (char, escape, backspace)
import qualified Util   (modelArg, splineArg, frequency)
import qualified Screen (setup, blank, scale, yaw, pitch, roll, kill, reset,
                         position, axes, move, lineTo, swap)

detail :: Num a => a
detail = 2000

fps :: Num a => a
fps = 60

main :: IO ()
main = do
  -- Create a window and load the resources.
  v <- Screen.setup 800 600 False
  m <- Model.load =<< Util.modelArg
  s <- Spline.load =<< Util.splineArg
  l <- Model.fromSpline detail s

  Util.frequency fps $ \i -> do

    Screen.blank

    -- Handle keyboard input.
    Input.char '+' $ Screen.scale v (* 1.05)
    Input.char '-' $ Screen.scale v (* 0.95)
    Input.char 'A' $ Screen.yaw   v (+ 2)
    Input.char 'D' $ Screen.yaw   v (subtract 2)
    Input.char 'W' $ Screen.pitch v (+ 2)
    Input.char 'S' $ Screen.pitch v (subtract 2)
    Input.char 'Q' $ Screen.roll  v (+ 2)
    Input.char 'E' $ Screen.roll  v (subtract 2)

    Input.escape    $ Screen.kill
    Input.backspace $ Screen.reset v

    Screen.position v
    Screen.axes

    Model.draw l

    let t = fromIntegral (i `rem` detail) / detail -- Make t loop along [0..1].
    let point = Spline.inter s t -- Current t corresponds to a curve point.

    Screen.move point

    let g = Spline.tangent s t
    Screen.lineTo g  -- Draws the tangent.

    Model.orient m g -- Orients the model same as the tangent.
    Model.draw m

    Screen.swap
