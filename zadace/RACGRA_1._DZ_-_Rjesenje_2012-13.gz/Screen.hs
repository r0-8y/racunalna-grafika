{-# LANGUAGE TemplateHaskell, FlexibleContexts #-}

module Screen where

import Data.Lenses (fetch, alter)
import Data.Lenses.Template (deriveLenses)

import Data.IORef
import System.Exit (exitSuccess)

import Graphics.UI.GLFW
import Graphics.Rendering.OpenGL.GL
import Graphics.Rendering.OpenGL.GLU.Matrix (perspective, lookAt)


type ViewRef = IORef View

data View = View {
  viewScale_ :: GLfloat,
  viewRoll_  :: GLfloat,
  viewYaw_   :: GLfloat,
  viewPitch_ :: GLfloat
}

$(deriveLenses ''View)

view :: View
view = View 1 0 0 0

-- Create the window and prepare for drawing.
setup :: Int -> Int -> Bool -> IO ViewRef
setup w h full = do
  initialize
  openWindow $ displayOptions w h full

  -- Set the perspective.
  matrixMode $= Projection
  perspective 45 (fromIntegral w / fromIntegral h) 0.01 100

  -- Set the camera.
  let (cameraAt, origin) = (Vertex3 10 10 10, Vertex3 0 0 0)
  lookAt cameraAt origin $ Vector3 0 1 0

  -- Quit when window closed.
  setWindowCloseCallback $ kill >> return True

  -- Prepare for drawing.
  matrixMode $= Modelview 0
  clearColor $= black
  clientState VertexArray $= Enabled
  color white

  -- Return the starting view.
  newIORef view

kill :: IO ()
kill = exitSuccess

white :: Color4 GLclampf
white = Color4 1 1 1 1

gray :: Color4 GLclampf
gray = Color4 0.5 0.5 0.5 1

black :: Color4 GLclampf
black = Color4 0 0 0 1

red :: Color4 GLclampf
red = Color4 1 0 0 1

green :: Color4 GLclampf
green = Color4 0 1 0 1

blue :: Color4 GLclampf
blue = Color4 0 0 1 1

swap :: IO ()
swap = swapBuffers

reset :: ViewRef -> IO ()
reset = flip writeIORef view

blank :: IO ()
blank = do
  clear [ColorBuffer]
  loadIdentity
  polygonMode $= (Fill, Fill)

scalef :: GLfloat -> IO ()
scalef f = Graphics.Rendering.OpenGL.GL.scale f f f

-- Read the ViewRef and set the scale, rotate and other values.
position :: ViewRef -> IO ()
position vref = do
  v <- readIORef vref
  scalef (v `fetch` viewScale)
  rotate (v `fetch` viewPitch) $ Vector3 1 0 0
  rotate (v `fetch` viewYaw)   $ Vector3 0 1 0
  rotate (v `fetch` viewRoll)  $ Vector3 0 0 1

vertexf :: GLfloat -> GLfloat -> GLfloat -> IO ()
vertexf x y z = vertex $ Vertex3 x y z

axes :: IO ()
axes = renderPrimitive Lines $ do
  color red
  vertexf 0 0 0
  vertexf 100 0 0
  color green
  vertexf 0 0 0
  vertexf 0 100 0
  color blue
  vertexf 0 0 0
  vertexf 0 0 100
  color white

lineTo :: Vector3 GLfloat -> IO ()
lineTo (Vector3 x y z )=
  renderPrimitive Lines $ do
    color green
    vertexf 0 0 0
    vertexf x y z
    color white

move :: Vector3 GLfloat -> IO ()
move = translate

scale :: ViewRef -> (GLfloat -> GLfloat) -> IO ()
scale v f = modifyIORef v $ alter viewScale f

yaw :: ViewRef -> (GLfloat -> GLfloat) -> IO ()
yaw v f = modifyIORef v $ alter viewYaw f

pitch :: ViewRef -> (GLfloat -> GLfloat) -> IO ()
pitch v f = modifyIORef v $ alter viewPitch f

roll :: ViewRef -> (GLfloat -> GLfloat) -> IO ()
roll v f = modifyIORef v $ alter viewRoll f

-- What kind of window are we creating?
displayOptions :: Int -> Int -> Bool -> DisplayOptions
displayOptions w h full = defaultDisplayOptions {
  displayOptions_width = w,
  displayOptions_height = h,
  displayOptions_numRedBits = 8,
  displayOptions_numGreenBits = 8,
  displayOptions_numBlueBits = 8,
  displayOptions_windowIsResizable = False,
  displayOptions_displayMode = if full then Fullscreen else Window,
  displayOptions_refreshRate = Nothing
}
