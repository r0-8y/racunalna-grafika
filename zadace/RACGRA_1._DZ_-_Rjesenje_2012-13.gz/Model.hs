{-# LANGUAGE TemplateHaskell, FlexibleContexts #-}

module Model (load, fromSpline, draw, orient, Model) where

import Data.Lenses (fetch)
import Data.Lenses.Template (deriveLenses)

import Graphics.Rendering.OpenGL.GL
import Graphics.GLUtil (makeBuffer, offset0)
import Data.IORef (newIORef, readIORef, writeIORef, IORef)

import Data.List (genericLength)
import Data.IntMap.Strict (IntMap, fromList, (!))

import Spline (Spline, vertices)


-- A model loaded into memory, represented by a buffer object, the
-- number of vertex groups contained within, a mode used to draw them
-- and a ref containing the target rotation.
data Model = Model {
  vbo_    :: BufferObject,
  num_    :: GLsizei,
  method_ :: PrimitiveMode,
  direct_ :: IORef (GLfloat, Vector3 GLfloat)
}

$(deriveLenses ''Model)


-- Small helper for easier vertex array generation.
type Tup3 a = (a, a, a)


-- Load an .obj file into memory.
load :: FilePath -> IO Model
load path = do
  -- Get the lines containing vertices and faces, separate them.
  ls <- lines `fmap` readFile path
  let (verts, faces) = (ls `startingWith` 'v', ls `startingWith` 'f')

-- How many triangles does the model consist of?
  let num = genericLength faces * 3

  -- Construct a vertex map, keyed by order of appearance.
  let vmap = fromList . zip [1..] $ map nums verts

  -- Construct and send the finished vertex array to vcard memory.
  let array = concat . generate vmap $ map nums faces
  vbo <- makeBuffer ArrayBuffer array

  -- Return a model oriented towards the positive Z axis.
  Model vbo num Triangles `fmap` newIORef noRotate

  where
    -- Convert a .obj line containing numbers into a number tuple.
    nums :: (Read a, Num a) => String -> (a, a, a)
    nums s = let [a, b, c] = map read . tail $ words s
             in  (a, b, c)

    -- Generate the vertex array that is to be sent to vcard memory.
    generate :: IntMap (Tup3 GLfloat) -> [Tup3 Int] -> [[GLfloat]]
    generate _ [] = []
    generate vmap ((a, b, c):fs) =
      let (x1, y1, z1) = vmap ! a
          (x2, y2, z2) = vmap ! b
          (x3, y3, z3) = vmap ! c
      in  [x1, y1, z1, x2, y2, z2, x3, y3, z3] : generate vmap fs

    -- Which of the given lines begin with a certain character?
    startingWith :: [String] -> Char -> [String]
    startingWith ls c = filter ((==c) . head) ls


-- Generate a model from a spline.
fromSpline :: Double -> Spline -> IO Model
fromSpline res s = do
  let vs = vertices res s
  let num = genericLength vs `div` 3
  vbo <- makeBuffer ArrayBuffer vs
  Model vbo num LineStrip `fmap` newIORef noRotate


-- Draw a model, assuming neccessary setup already done.
draw :: Model -> IO ()
draw m = do
  bindBuffer ArrayBuffer $= Just (m `fetch` vbo)
  arrayPointer VertexArray $= VertexArrayDescriptor 3 Float 0 offset0

  preservingMatrix $ do
    -- Rotate the model to the desired orientation.
    (a, os) <- readIORef $ m `fetch` direct
    rotate a os

    -- And finally draw it.
    drawArrays (m `fetch` method) 0 $ m `fetch` num


-- Set the angle and rotation axis needed for the model to achieve a
-- certain target orientation.
orient :: Model -> Vector3 GLfloat -> IO ()
orient m target = do
  let Vector3 ex ey ez = target
  let Vector3 sx sy sz = towardsZ -- Start orientation is always the same.

  let tx = sy*ez - ey*sz
  let ty = ex*sz - sx*ez
  let tz = sx*ey - sy*ex
  let os = Vector3 tx ty tz -- The rotation axis.

  -- Multiplied vector norms.
  let es = sqrt $ (ex**2 + ey**2 + ez**2) * (sx**2 + sy**2 + sz**2)

  -- Get the needed angle.
  let a = 180 / pi * acos ((ex*sx + ey*sy + ez*sz) / es)

  -- We remember this information so Model.draw can use it.
  writeIORef (m `fetch` direct) (a, os)


-- The starting orientation is always towards positive Z.
towardsZ :: Vector3 GLfloat
towardsZ = Vector3 0 0 1

-- The default needed rotation parameters.
noRotate :: (GLfloat, Vector3 GLfloat)
noRotate = (0, Vector3 0 0 0)
