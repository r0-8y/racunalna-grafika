module Util where

import System.Environment (getArgs)
import Control.Concurrent (threadDelay)
import Control.Monad (forM_)

wait :: Double -> IO ()
wait = threadDelay . round . (*1000000)

modelArg :: IO FilePath
modelArg = head `fmap` getArgs

splineArg :: IO FilePath
splineArg = (!! 1) `fmap` getArgs

frequency :: Double -> (Int -> IO ()) -> IO ()
frequency freq act = do
  forM_ [0..] $ \i -> do
    act i
    wait $ 1 / freq
