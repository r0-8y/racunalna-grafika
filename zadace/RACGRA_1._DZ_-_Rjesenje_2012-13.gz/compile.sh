#!/usr/bin/env sh

if ghc --make Main.hs -O2 -o rg1 -threaded;
then
  strip rg1;
#  ./rg1 $@;
fi

#if ghc --make Main.hs -O3 -threaded -dynamic -o rg1-dyn -osuf .o;
#then
#  strip rg1-dyn;
#  ./rg1-dyn $@;
#fi
