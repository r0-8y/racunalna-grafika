module Spline (load, inter, vertices, tangent, Spline) where

import Numeric.Container hiding (Vector)
import Graphics.Rendering.OpenGL.GL (Vertex3(..), GLfloat, Vector3(..))


-- A spline represented by functions to generate it.
data Spline = Spline
  (Double -> Vertex3 GLfloat) -- Interpolator for t <- [0..1]
  (Double -> Vector3 GLfloat) -- Gets tangent on point for a t.

-- Load a spline from a file.
load :: FilePath -> IO Spline
load path = do
  m <- loadMatrix path
  return $ Spline (makeInterF m) (makeTangentF m)

-- What point on the curve corresponds to a certain t <- [0, 1]?
inter :: Spline -> Double -> Vector3 GLfloat
inter (Spline i _) t =
  let Vertex3 x y z = i t
  in  Vector3 x y z

-- Get the tangent for a point corresponding to a certain t <- [0, 1].
tangent :: Spline -> Double -> Vector3 GLfloat
tangent (Spline _ g) t = g t

-- Generate vertices for all interpolated points on a spline, given a
-- certain resolution r.
vertices :: Double -> Spline -> [GLfloat]
vertices r (Spline i _) = loop $ resolution r
  where
    resolution :: Double -> [Double]
    resolution r = [0, 1/r .. 1]

    loop [] = []
    loop (t:rest) =
      let Vertex3 x y z = i t
      in  x : y : z : loop rest


-- All the matrices we deal with contain Doubles.
type Mat = Matrix Double

-- Create a function that interpolates points within the entire
-- spline, over all segments, given a t <- [0, 1].
makeInterF :: Mat -> Double -> Vertex3 GLfloat
makeInterF spl = makeFunc spl magic tgen Vertex3
  where
    raw   = (4 >< 4) [-1, 3, -3, 1, 3, -6, 3, 0, -3, 0, 3, 0, 1, 4, 1, 0]
    magic = scale (1/6) raw
    tgen = \t -> (1 >< 4) [t**3, t**2, t, 1]

-- Create a function that returns the tangent for a spline point
-- corresponding to a given t <- [0, 1].
makeTangentF :: Mat -> Double -> Vector3 GLfloat
makeTangentF spl = makeFunc spl magic tgen Vector3
  where
    magic = scale (1/2) $ (3 >< 4) [-1, 3, -3, 1, 2, -4, 2, 0, -1, 0, 1, 0]
    tgen  = \t -> (1 >< 3) [t**2, t, 1]

-- Helper type for constructors such as Vector3 and Vertex3.
type Make v = (GLfloat -> GLfloat -> GLfloat -> v GLfloat)

-- Create functions operating on select 4 rows of spline data, given a
-- certain t <- [0, 1].
makeFunc :: Mat -> Mat -> (Double -> Mat) -> Make v -> Double -> v GLfloat
makeFunc spl magic tgen mk t' = mk x y z
  where
    -- What's the last node we're allowed to start with?
    max'd = rows spl - 4 :: Int

    -- Expand from [0, 1] to [0, X].
    p = t' * fromIntegral (max'd + 1) :: Double

    -- Our first pick for the node is...
    n' = floor p :: Int

    -- We revise our pick if it's too large.
    n | n' > max'd = max'd
      | otherwise   = n'

    -- Take the needed four rows.
    rs = takeRows 4 $ dropRows n spl

    -- Now we need to get the local specific t in [0, 1].
    t = p - fromIntegral n

    -- Multiply the matrices together and get the result.
    fin = toList.head.toRows $ tgen t `multiply` magic `multiply` rs

    -- Convert result to GLfloats.
    [x, y, z] = map realToFrac fin
